object Lab3Grader {
  def main(args: Array[String]) {
    (new Lab3Grading).execute(stats = true)
  }
}
