object Lab2Grader {
  def main(args: Array[String]) {
    (new Lab2Grading).execute(stats = true)
  }
}